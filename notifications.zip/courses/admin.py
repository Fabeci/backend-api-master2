# courses/admin.py
from django.contrib import admin
from django.db.models import Count
from .models import Cours, Module, Sequence, Session, InscriptionCours, Participation, Suivi

# ---------- Inlines ----------
class ModuleInline(admin.TabularInline):
    model = Module
    extra = 0
    fields = ("titre", "description")
    show_change_link = True

class SequenceInline(admin.TabularInline):
    model = Sequence
    extra = 0
    fields = ("titre",)
    show_change_link = True

class SessionInline(admin.TabularInline):
    model = Session
    extra = 0
    fields = ("titre", "date_debut", "date_fin", "formateur")
    show_change_link = True

class ParticipationInline(admin.TabularInline):
    model = Participation
    extra = 0
    autocomplete_fields = ("apprenant",)
    fields = ("apprenant", "date_participation")
    show_change_link = True


# ---------- Cours ----------
@admin.register(Cours)
class CoursAdmin(admin.ModelAdmin):
    list_display = (
        "id", "matiere", "groupe", "enseignant", "date", "heure",
        "nb_modules", "nb_sessions", "nb_inscriptions",
    )
    list_filter = ("groupe", "enseignant", "matiere", "date")
    search_fields = (
        "groupe__nom", "enseignant__nom", "enseignant__prenom", "matiere__nom",
    )
    inlines = [ModuleInline, SessionInline]
    autocomplete_fields = ("groupe", "enseignant", "matiere")

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.select_related("groupe", "enseignant", "matiere") \
                 .annotate(_modules=Count("modules"),
                           _sessions=Count("sessions"),
                           _inscriptions=Count("inscriptions"))

    def nb_modules(self, obj): return obj._modules
    nb_modules.short_description = "Modules"

    def nb_sessions(self, obj): return obj._sessions
    nb_sessions.short_description = "Sessions"

    def nb_inscriptions(self, obj): return obj._inscriptions
    nb_inscriptions.short_description = "Inscriptions"


# ---------- Module ----------
@admin.register(Module)
class ModuleAdmin(admin.ModelAdmin):
    list_display = ("id", "titre", "cours", "nb_sequences")
    search_fields = ("titre", "cours__matiere__nom", "cours__groupe__nom", "cours__enseignant__nom")
    list_filter = ("cours__matiere", "cours__groupe", "cours__enseignant")
    autocomplete_fields = ("cours",)
    inlines = [SequenceInline]

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.select_related("cours", "cours__matiere", "cours__groupe", "cours__enseignant") \
                 .annotate(_sequences=Count("sequences"))

    def nb_sequences(self, obj): return obj._sequences
    nb_sequences.short_description = "Séquences"


# ---------- Sequence ----------
@admin.register(Sequence)
class SequenceAdmin(admin.ModelAdmin):
    list_display = ("id", "titre", "module", "cours_affiche")
    search_fields = ("titre", "module__titre", "module__cours__matiere__nom")
    list_filter = ("module__cours__matiere",)
    autocomplete_fields = ("module",)

    def cours_affiche(self, obj):
        return obj.module.cours
    cours_affiche.short_description = "Cours"


# ---------- Session ----------
@admin.register(Session)
class SessionAdmin(admin.ModelAdmin):
    list_display = ("id", "titre", "cours", "formateur", "date_debut", "date_fin", "participants_count")
    list_filter = ("cours__matiere", "formateur", "date_debut", "date_fin")
    search_fields = ("titre", "cours__matiere__nom", "formateur__nom", "formateur__prenom")
    autocomplete_fields = ("cours", "formateur")
    inlines = [ParticipationInline]

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.select_related("cours", "formateur", "cours__matiere", "cours__groupe") \
                 .annotate(_participants=Count("participations"))

    def participants_count(self, obj): return obj._participants
    participants_count.short_description = "Participants"


# ---------- InscriptionCours ----------
@admin.register(InscriptionCours)
class InscriptionCoursAdmin(admin.ModelAdmin):
    list_display = ("id", "apprenant_nom", "apprenant_prenom", "cours", "statut", "date_inscription")
    list_filter = ("statut", "cours__matiere", "cours__groupe")
    search_fields = (
        "apprenant__email", "apprenant__nom", "apprenant__prenom",
        "cours__matiere__nom", "cours__groupe__nom"
    )
    autocomplete_fields = ("apprenant", "cours")
    date_hierarchy = "date_inscription"

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.select_related("apprenant", "cours", "cours__matiere", "cours__groupe")

    def apprenant_nom(self, obj): return obj.apprenant.nom
    def apprenant_prenom(self, obj): return obj.apprenant.prenom
    apprenant_nom.short_description = "Nom"
    apprenant_prenom.short_description = "Prénom"


# ---------- Suivi ----------
@admin.register(Suivi)
class SuiviAdmin(admin.ModelAdmin):
    list_display = ("id", "apprenant", "cours", "progression", "note", "date_debut")
    list_filter = ("cours__matiere", "cours__groupe")
    search_fields = (
        "apprenant__email", "apprenant__nom", "apprenant__prenom",
        "cours__matiere__nom", "cours__groupe__nom"
    )
    autocomplete_fields = ("apprenant", "cours")
    list_editable = ("progression", "note")
    actions = ("reset_progression",)

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.select_related("apprenant", "cours", "cours__matiere", "cours__groupe")

    @admin.action(description="Réinitialiser la progression à 0%")
    def reset_progression(self, request, queryset):
        updated = queryset.update(progression=0.0)
        self.message_user(request, f"Progression réinitialisée pour {updated} suivi(s).")


# ---------- Participation ----------
@admin.register(Participation)
class ParticipationAdmin(admin.ModelAdmin):
    list_display = ("id", "session", "apprenant", "date_participation")
    list_filter = ("session__cours__matiere", "session__formateur")
    search_fields = (
        "session__titre", "apprenant__email", "apprenant__nom", "apprenant__prenom",
    )
    autocomplete_fields = ("session", "apprenant")

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.select_related("session", "session__cours", "apprenant")
